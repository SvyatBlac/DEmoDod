using System.IO;
using System.Windows.Markup;
using System.Xml;

namespace XamlCopy
{
    public class XamlManipulaitor
    {
        static public object Copy(object obj)
        {
            string gridXaml = XamlWriter.Save(obj);
            StringReader stringReader = new StringReader(gridXaml);
            XmlReader xmlReader = XmlReader.Create(stringReader);
            return XamlReader.Load(xmlReader) as object;
        }
    }
}
